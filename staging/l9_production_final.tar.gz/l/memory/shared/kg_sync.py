# l/memory/shared/kg_sync.py

from memory.l1.l1_reader import reader
from memory.l1.l1_writer import writer
from memory.shared.logging_hooks import hooks
from memory.shared.supabase_client import get_supabase

class KGSync:
    def __init__(self):
        self.sb = get_supabase()

    def sync_decisions_to_neo4j(self):
        decisions = reader.get_decisions(limit=50).data
        # push via REST → your Neo4j endpoint
        # (neo4j connector to be added)
        return decisions

sync = KGSync()

