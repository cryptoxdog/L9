from fastapi import APIRouter, Header, HTTPException
from l.memory.memory_router_v4 import MemoryRouterV4

router = APIRouter()
memory = MemoryRouterV4()

# API key enforcement
def require_api_key(x_api_key: str = Header(None)):
    if not x_api_key:
        raise HTTPException(status_code=401, detail="Missing X-API-Key header")
    return x_api_key

@router.post("/L/test/write")
def test_write(payload: dict, x_api_key: str = Header(None)):
    require_api_key(x_api_key)
    # minimal valid L1 entry
    entry = {
        "directive": payload,
        "source": "test_harness",
        "priority": 5
    }
    return memory.write("l_directives", entry)

@router.get("/L/test/read")
def test_read(x_api_key: str = Header(None)):
    require_api_key(x_api_key)
    result = memory.read("l_directives", {"source": "test_harness"})
    return {"items": result.data if hasattr(result, 'data') else result}

