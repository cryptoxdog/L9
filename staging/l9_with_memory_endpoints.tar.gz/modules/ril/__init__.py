"""
RIL (Relational Intelligence Layer) Module
"""
from .adapter import handles, run

__all__ = ["handles", "run"]
